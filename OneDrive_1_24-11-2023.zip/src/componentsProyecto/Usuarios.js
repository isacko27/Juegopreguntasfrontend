import React from 'react';
import { useState, useEffect } from 'react';
//fuente: https://www.codingthesmartway.com/how-to-fetch-api-data-with-react/
const Usuarios = _ => {
    const [usuarios, setUsuarios] = useState([]);
    const hostBackend = 'localhost';
    const portBackend = 8000;
    const urlBase = `http://${hostBackend}:${portBackend}`;

    useEffect(() => {
        fetchusuariosData()
    }, []);

    //consume api json
    const fetchusuariosData = () => {
        //console.log(urlBase + "/listausuarios");
        fetch(urlBase + "/listausuarios")
            .then(response => {
                return response.json()
            })
            .then(data => {
                setUsuarios(data)
            })
    }

    return (
        <section>
            <h1>Lista de usuarios del proyecto</h1>
            {usuarios.length > 0 && (
                <ul>
                    {usuarios.map(usuario => (
                        <article key={usuario.nickname}><b>Usuario:</b> {usuario.nickname}
                        <section><b>Preferencias:</b> {usuario.preferencias.musica} & {usuario.preferencias.series}</section>
                        <section>
                        <b>Historial:</b>
                        {usuario.historial != null && usuario.historial.map(histo => (
                            <li key={histo}>{histo}</li>
                            ))}
                        </section>
                        </article>
                    ))}
                </ul>
            )}
        </section>
    );

}

export default Usuarios;